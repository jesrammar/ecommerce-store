from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import get_object_or_404, redirect, render

from productos.models import Producto
from pedidos.models import Pedido
from .forms import ProductoForm


# ---------- Dashboard ----------
@staff_member_required(login_url="accounts:login")
def dashboard(request):
    productos_total = Producto.objects.count()
    pedidos_total = Pedido.objects.count()
    pedidos_pendientes = Pedido.objects.filter(estado="pendiente").count()
    pedidos_ultimos = Pedido.objects.order_by("-id")[:10]

    ctx = {
        "productos_total": productos_total,
        "pedidos_total": pedidos_total,
        "pedidos_pendientes": pedidos_pendientes,
        "pedidos_ultimos": pedidos_ultimos,
    }
    return render(request, "gestion/dashboard.html", ctx)


# ---------- Productos (CRUD) ----------
@staff_member_required(login_url="accounts:login")
def admin_producto_list(request):
    qs = Producto.objects.order_by("-id")
    return render(request, "gestion/producto_list.html", {"productos": qs})


@staff_member_required(login_url="accounts:login")
def admin_producto_create(request):
    if request.method == "POST":
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Producto creado correctamente.")
            return redirect("gestion:admin_producto_list")
    else:
        form = ProductoForm()
    return render(request, "gestion/producto_form.html", {"form": form, "modo": "crear"})


@staff_member_required(login_url="accounts:login")
def admin_producto_update(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == "POST":
        form = ProductoForm(request.POST, request.FILES, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, "Producto actualizado.")
            return redirect("gestion:admin_producto_list")
    else:
        form = ProductoForm(instance=producto)
    return render(
        request,
        "gestion/producto_form.html",
        {"form": form, "modo": "editar", "producto": producto},
    )


@staff_member_required(login_url="accounts:login")
def admin_producto_delete(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == "POST":
        producto.delete()
        messages.success(request, "Producto eliminado.")
        return redirect("gestion:admin_producto_list")
    return render(request, "gestion/producto_confirm_delete.html", {"producto": producto})


# ---------- Pedidos ----------
@staff_member_required(login_url="accounts:login")
def admin_pedido_list(request):
    pedidos = Pedido.objects.order_by("-id")
    return render(request, "gestion/pedidos_list.html", {"pedidos": pedidos})


@staff_member_required(login_url="accounts:login")
def admin_pedido_detail(request, pk):
    pedido = get_object_or_404(Pedido, pk=pk)
    return render(request, "gestion/pedido_detail.html", {"pedido": pedido})


@staff_member_required(login_url="accounts:login")
def admin_pedido_update_estado(request, pk):
    pedido = get_object_or_404(Pedido, pk=pk)
    if request.method == "POST":
        nuevo_estado = (request.POST.get("estado") or "").strip()
        if nuevo_estado:
            pedido.estado = nuevo_estado
            pedido.save(update_fields=["estado"])
            messages.success(request, "Estado del pedido actualizado.")
        else:
            messages.error(request, "Debes indicar un estado válido.")
    return redirect("gestion:admin_pedido_detail", pk=pk)
