from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.shortcuts import get_object_or_404, redirect, render, resolve_url
from django.utils.http import url_has_allowed_host_and_scheme

from .forms import RegistroForm, PerfilForm, AddressForm
from .models import Address


def _safe_next(request):
    """
    Devuelve la URL de retorno si es segura (misma host) y viene en POST o GET.
    """
    nxt = (request.POST.get("next") or request.GET.get("next") or "").strip()
    if nxt and url_has_allowed_host_and_scheme(nxt, allowed_hosts={request.get_host()}):
        return nxt
    return None


def _fallback_url(default_name="productos:catalogo"):
    """
    Fallback robusto para redirecciones después de login/logout.
    Usa settings.LOGIN_REDIRECT_URL o settings.LOGOUT_REDIRECT_URL si existen
    y, si no, cae al nombre de URL indicado.
    """
    return default_name



def registro(request):
    if request.method == "POST":
        form = RegistroForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data["password"])
            user.save()
            messages.success(request, "Registro completado. Ya puedes iniciar sesión.")
          
            return redirect("accounts:login")
    else:
        form = RegistroForm()
    return render(request, "accounts/registro.html", {"form": form})


def login_view(request):
    """
    Login con usuario o email. Respeta ?next= si es seguro.
    Evita NoReverseMatch usando fallback cuando LOGIN_REDIRECT_URL no esté definido.
    """
    # 👇 NUEVO: si ya está autenticado, fuera del login
    if request.user.is_authenticated:
        redirect_name = getattr(settings, "LOGIN_REDIRECT_URL", "productos:catalogo")
        return redirect(resolve_url(redirect_name))

    if request.method == "POST":
        username_or_email = (request.POST.get("username") or "").strip()
        password = request.POST.get("password") or ""

        # Permitir email o username
        User = get_user_model()
        username = username_or_email
        if "@" in username_or_email:
            try:
                u = User.objects.get(email__iexact=username_or_email)
                username = u.get_username()
            except User.DoesNotExist:
                pass

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Has iniciado sesión.")

            nxt = _safe_next(request)
            if nxt:
                return redirect(nxt)

            redirect_name = getattr(settings, "LOGIN_REDIRECT_URL", None) or _fallback_url()
            return redirect(resolve_url(redirect_name))

        messages.error(request, "Credenciales inválidas.")

    return render(request, "accounts/login.html", {"next": _safe_next(request)})




def logout_view(request):
    logout(request)
    messages.info(request, "Has cerrado sesión.")
    redirect_name = getattr(settings, "LOGOUT_REDIRECT_URL", None) or _fallback_url()
    return redirect(resolve_url(redirect_name))



@login_required
def perfil(request):
    perfil = request.user.profile
    if request.method == "POST":
        form = PerfilForm(request.POST, instance=perfil)
        if form.is_valid():
            form.save()
            messages.success(request, "Perfil actualizado.")
            return redirect("accounts:perfil")
    else:
        form = PerfilForm(instance=perfil)
    direcciones = request.user.addresses.all().order_by("-es_predeterminada", "id")
    return render(request, "accounts/perfil.html", {"form": form, "direcciones": direcciones})


@login_required
def address_create(request):
    if request.method == "POST":
        form = AddressForm(request.POST)
        if form.is_valid():
            addr = form.save(commit=False)
            addr.user = request.user
            addr.save()
            if not request.user.addresses.filter(es_predeterminada=True).exists():
                addr.es_predeterminada = True
                addr.save()
                request.user.profile.direccion_envio_pred = addr
                request.user.profile.save()
            messages.success(request, "Dirección añadida.")
            return redirect("accounts:perfil")
    else:
        form = AddressForm()
    return render(request, "accounts/address_form.html", {"form": form})


@login_required
def address_edit(request, pk):
    addr = get_object_or_404(Address, pk=pk, user=request.user)
    if request.method == "POST":
        form = AddressForm(request.POST, instance=addr)
        if form.is_valid():
            form.save()
            messages.success(request, "Dirección actualizada.")
            return redirect("accounts:perfil")
    else:
        form = AddressForm(instance=addr)
    return render(request, "accounts/address_form.html", {"form": form})


@login_required
def address_delete(request, pk):
    addr = get_object_or_404(Address, pk=pk, user=request.user)
    if request.method == "POST":
        addr.delete()
        messages.success(request, "Dirección eliminada.")
        return redirect("accounts:perfil")
    return render(request, "accounts/address_confirm_delete.html", {"addr": addr})


@login_required
def address_make_default(request, pk):
    addr = get_object_or_404(Address, pk=pk, user=request.user)
    request.user.addresses.update(es_predeterminada=False)
    addr.es_predeterminada = True
    addr.save()
    request.user.profile.direccion_envio_pred = addr
    request.user.profile.save()
    messages.success(request, "Dirección establecida como predeterminada.")
    return redirect("accounts:perfil")
